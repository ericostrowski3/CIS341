﻿namespace CIS341_lab3.Models
{
    public class ContactForm
    {
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string Message { get; set; }
    }
}
