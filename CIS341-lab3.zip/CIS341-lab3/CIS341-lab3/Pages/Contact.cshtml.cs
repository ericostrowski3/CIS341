using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CIS341_lab3.Models;  
using System.Diagnostics;

namespace CIS341_lab3.Pages
{
    public class ContactModel : PageModel
    {
        public ContactForm ContactFormData { get; set; } = new ContactForm();

        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {

            Debug.WriteLine($"Name: {ContactFormData.Name}, Email Address: {ContactFormData.EmailAddress}, Message: {ContactFormData.Message}");

            return RedirectToPage("Index");
        }
    }
}
